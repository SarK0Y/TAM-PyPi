from sark0y_tam import _tam
_tam.cmd()
